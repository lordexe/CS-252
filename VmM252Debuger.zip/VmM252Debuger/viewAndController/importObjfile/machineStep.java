package viewAndController.importObjfile;


import Packages.vm252architecturespecifications.VM252ArchitectureSpecifications;
import Packages.vm252architecturespecifications.VM252ArchitectureSpecifications.Instruction;

import java.lang.Math;
import model.*;
public class machineStep {
    private VM252DebuggerModel myModelState;
    private 
}
