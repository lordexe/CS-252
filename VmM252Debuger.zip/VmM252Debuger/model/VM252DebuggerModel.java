package model;
import observation.*;
import Packages.vm252architecturespecifications.*;
public class VM252DebuggerModel extends SimpleObservable
{

    private short myACC;
    private short myPC;
    private byte [] myMemory;
    private String instruction;
    private String [] displayContents;
    private short breakPoint;
    private boolean HaltingInstruction;

    //Accessors

    public byte memoryByte(int address) throws IllegalArgumentException
        {

            if (address < 0
                    || VM252ArchitectureSpecifications.MEMORY_SIZE_IN_BYTES <= address)

                throw
                    new IllegalArgumentException(
                        "Attempt to getch memory byte from illegal memory address " + address
                        );

            else

                return myMemory[ address ];

            }
    
    

    public short getACCValue()
    {

        return myACC;

        }

    public short getPCValue()
    {

        return myPC;

        }

    public byte[] getMemoryValue()
    {

        return myMemory;

        }
    
    public String getInstruction(){
        return instruction;
    }

    public String [] getDisplayContents()
    {
        return displayContents;
    }

    //Murators

    public void setACCValue(Short other)
    {

        myACC = other;

        announceChange();

        }

    public void setPCValue(Short other)
    {

        myPC = other;

        announceChange();

        }

    public void setMemoryValue(byte [] other)
    {

        myMemory = other;

        announceChange();

        }
    
    public void setInstruction(String other) {
        instruction = other;
    }

    public void setDisplayContents(String [] other)
    {
        displayContents = other;
        announceChange();
    }

    public void resetDisplayContents()
    {
        String [] contents = {""};
        displayContents = contents;
    }

    public short getBreakPoint()
    {
        return breakPoint;
    }

    public void setBreakPoint(short other)
    {
        breakPoint = other;
    }

    public boolean getHaltStatus()
    {
        return HaltingInstruction;
    }

    public void setHalt(boolean other)
    {
       HaltingInstruction = other;
    }

    // Ctors

    public VM252DebuggerModel()
    {

        super();
        String [] welcomeContents = {"Welcome to VM252 debugger GUI"};


        setACCValue((short) 0);
        setPCValue((short) 0);
        setMemoryValue(new byte [8192]);
        setInstruction("Null");
        setDisplayContents(welcomeContents);

    }

        VM252DebuggerModel(byte [] programEncoded)
    {

        super();
        byte [] memory = new byte[ 8192 ];
        String [] welcomeContents = {""};

        setACCValue((short)0);
        setPCValue((short) 0);
        setMemoryValue(VM252ArchitectureSpecifications.Instruction.Instruction(programEncoded));
        setInstruction(initialInstruction);
        setDisplayContents(initialDisplayContents);

    }
    
    public void runPrograme ()
    {
        byte [] encodedInstruction
            = VM252ArchitectureSpecifications.fetchBytePair(getMemoryValue(), getPCValue());

        int [] decodedInstruction
            = VM252ArchitectureSpecifications.decodedInstructionComponents(encodedInstruction);
        int opcode = decodedInstruction[ 0 ];

        short operand
            = decodedInstruction.length == 2
                ? ((short) (decodedInstruction[ 1 ]))
                : 0;

        setSuppressPcStatus(false);

        //
        // Simulate execution of a VM252 instruction represented by opcode
        //     (and for instructions that have an operand, operand), altering
        //     accumulator, programCounter, and memory, as required
        // Let supressPcIncrement = true iff any kind of jump instruction was
        //     executed, a STOP instruction was executed, or a failed INPUT
        //     instruction was executed
        //

            switch (opcode) {

                case VM252ArchitectureSpecifications.LOAD_OPCODE -> {

                    resetDisplayContents();
                    setACCValue(VM252ArchitectureSpecifiecations.fetchIntegerValue(getMemoryValue(), operand));
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "LOAD " + operand});

                    }

                case VM252ArchitectureSpecifications.SET_OPCODE -> {

                    resetDisplayContents();
                    setACCValue(operand);
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "SET " + operand});

                    }

                case VM252ArchitectureSpecifications.STORE_OPCODE -> {

                    resetDisplayContents();
                    byte [] newMemory = VM252ArchitectureSpecifications.storeIntegerValue(getMemoryValue(), operand, getACCValue());
                    setMemoryValue(newMemory);
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "STORE " + operand});

                    }

                case VM252ArchitectureSpecifications.ADD_OPCODE -> {

                    resetDisplayContents();
                    setACCValue((short)(getACCValue() + VM252ArchitectureSpecifications.fetchIntegerValue(getMemoryValue(), operand)));
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "ADD " + operand});

                    }

                case VM252ArchitectureSpecifications.SUBTRACT_OPCODE -> {

                    resetDisplayContents();
                    setACCValue((short)(getACCValue() - VM252ArchitectureSpecifications.fetchIntegerValue(getMemoryValue(), operand)));
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "SUBTRACT " + operand});

                    }

                case VM252ArchitectureSpecifications.JUMP_OPCODE -> {

                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "JUMP " + operand});
                    resetDisplayContents();
                    setPCValue(operand);
                    setSuppressPcStatus(true);

                    }

                case VM252ArchitectureSpecifications.JUMP_ON_ZERO_OPCODE -> {

                    resetDisplayContents();
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "JUMPZ " + operand});
                    if (getACCValue() == 0) {
                        resetDisplayContents();
                        setPCValue(operand);
                        setSuppressPcStatus(true);
                        }
                    }

                case VM252ArchitectureSpecifications.JUMP_ON_POSITIVE_OPCODE -> {

                    resetDisplayContents();
                    setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "JUMPP " + operand});
                    resetDisplayContents();
                    if (getACCValue() > 0) {
                        setPCValue(operand);
                        setSuppressPcStatus(true);
                        }
                    }

                case VM252ArchitectureSpecifications.INPUT_OPCODE -> {

                        resetDisplayContents();

                        setDisplayContents(new String [] {"Addr " + getPCValue() + ": " + "Running INPUT"});
                        while (!getInputReady())
                            resetDisplayContents();

                        setACCValue(getInputValue());
                        setDisplayContents(new String[] {"Addr " + getPCValue() + ": " + "Set Input value to " + getInputValue()});

                        setInputReady(false);

                    }

                case VM252ArchitectureSpecifications.OUTPUT_OPCODE -> {

                    String [] output = {"Addr " + getPCValue() + ": " + "OUTPUT: " + getACCValue()};
                    setDisplayContents(output);

                    }

                case VM252ArchitectureSpecifications.NO_OP_OPCODE -> {

                    ; // do nothing

                    }

                case VM252ArchitectureSpecifications.STOP_OPCODE -> {

                    setHalt(true);
                    String [] stopMessage = {"Addr " + getPCValue() + ": " + "Program Stops"};
                    setDisplayContents(stopMessage);
                    resetDisplayContents();
                    }

                }

            //
            // Increment the program counter to contain the address of the next
            //     instruction to execute, unless the program counter was already
            //     adjusted or the program is not continuing
            //

            if (! getHaltStatus() && ! getSuppressPcStatus())
            {

                resetDisplayContents();
                setPCValue(
                    (short)
                        ((getPCValue() + VM252ArchitectureSpecifications.instructionSize(opcode))
                            % VM252ArchitectureSpecifications.MEMORY_SIZE_IN_BYTES)
                        );
            }
            if (!getHaltStatus())
                setNextInst(VM252ArchitectureSpecifications.instructionToString(getMemoryValue(), getPCValue()));
        }



        private boolean getSuppressPcStatus() {
        return false;
    }



        private void setSuppressPcStatus(boolean b) {
        }
    


}