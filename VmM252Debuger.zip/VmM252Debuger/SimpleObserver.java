public interface SimpleObserver extends Observer
{

    }
