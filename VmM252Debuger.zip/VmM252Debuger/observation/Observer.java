package observation;


public interface Observer
{

    void update();
        //
        // Tell this object that the subject it's observing has changed state
        //

    }
