package observation;


public class SimpleObserver implements Observer
{

    public void update()
    {

        ; // do nothing

        }

    }
